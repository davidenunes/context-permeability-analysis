
```r
source("../R/experiment_utils.R")
```


Context Permeability Convergence Results
========================================

In this analysis, we analyse the context permeability model in terms of 
convergence. This is, the percentage of times a simulation has converged to 
total consensus and how many agent encounters were needed for this to happen. 


# Convergence for K-Regular Networks #
In this analysis we look at the convergence to consensus for simulations that use 
regular networks only. We will analyse two things: the *percentage of convergence to total consensus* and the *number of encounters* necessary to achieve concensus.


We first load the data related to convergence to consensus. In this first dataset, we can find a single boolean variable {1,0} that tells us wheather or not consensus was achieved. 

```r
# Read the Parameters for this experiment
params <- read.exp.parameters(param_file_name = "../data/regular_networks/param-space_2014-05-30_16:47:53experiment:0_.csv")

# read the adata related to consensus was achieved before
require(data.table)
convergence_data <- fread("../data/regular_networks/consensus_achieved.csv")
convergence_data <- as.data.frame(convergence_data)[, -ncol(convergence_data)]
convergence_data <- merge(convergence_data, params, by = "cfg.id")
```

We can now create a table to display the percentage of convergences to total 
consensus **for each value of k and number of networks**.


```r
require(reshape)
require(tables)

# filter some things out
fcdata <- melt.data.frame(convergence_data, id.vars = c("cfg.id", "run", "num.networks", 
    "network.0.k"), measure.vars = c("consensus-achieved"))

# I can also cast to obtain multiple values like summary this will be useful
# later for the table with the number of encounters convergence_table <-
# cast(fcdata, num.networks~network.0.k~value, sum)

# convergence_table

fcdata_table <- aggregate(data = fcdata, fcdata$value ~ num.networks + fcdata$network.0.k, 
    FUN = sum)
colnames(fcdata_table) <- c("num.networks", "k", "value")

# create a pretty table for latex
latex_table <- tabular(cast(fcdata_table, num.networks ~ k, value = "value"))
```



```r
html(latex_table)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">k</th>
</tr>
 <tr class="center">
  <th>num.networks</th>
  <th>1</th>
  <th>2</th>
  <th>3</th>
  <th>4</th>
  <th>5</th>
  <th>10</th>
  <th>20</th>
  <th>30</th>
  <th>40</th>
  <th>50</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td> 0</td>
  <td>  0</td>
  <td>  1</td>
  <td>  0</td>
  <td>  2</td>
  <td> 18</td>
  <td> 64</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td> 8</td>
  <td> 63</td>
  <td> 76</td>
  <td> 92</td>
  <td> 95</td>
  <td> 98</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>64</td>
  <td> 90</td>
  <td> 98</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td>84</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>96</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
</tbody>
</table>

```r

# I can also save this table to a file for later reference
latex(latex_table, file = "tex/regular_convergence.tex", booktabs = T, )
```


This table shows the percentage of simulation runs that converged to total consensus over 100 
independent runs. 

# Number of Encounters for K-Regular Networks 
Now we analise the number of encouters necessary to achieve consensus. Or the total number of encounters that 
were performed if consensus was not achieved. **The maximum number of simulation cycles is 2000.** The maximum
number of encounters is thus limited by the maximum number of simulation cycles (and in consequense steps). The 
data for the encounters contains the following variables.

```r
encounter_data <- fread("../data/regular_networks/num_encounters.csv")
encounter_data <- as.data.frame(encounter_data)[, -ncol(encounter_data)]
head(encounter_data)
```

```
##   step run cfg.id total-encounters
## 1 2000   6      1           200000
## 2 2000   3      1           200000
## 3 2000   8      1           200000
## 4 2000   1      1           200000
## 5 2000   5      1           200000
## 6 2000   4      1           200000
```

To get the information for how many networks were in the simulation and what was the k value we 
can merge the data like we have done previously. 

```r
encounter_data <- merge(encounter_data, params, by = "cfg.id")
```


We now filter some of the variables out.

```r
# filter some things out
fedata <- melt.data.frame(encounter_data, id.vars = c("cfg.id", "run", "num.networks", 
    "network.0.k"), measure.vars = c("total-encounters"))
head(fedata)
```

```
##   cfg.id run num.networks network.0.k         variable  value
## 1      1   6            1           1 total-encounters 200000
## 2      1   3            1           1 total-encounters 200000
## 3      1   8            1           1 total-encounters 200000
## 4      1   1            1           1 total-encounters 200000
## 5      1   5            1           1 total-encounters 200000
## 6      1   4            1           1 total-encounters 200000
```

```r

# filter encounter data include only num networks > 3
fedata_net1 <- fedata[fedata$num.networks > 2 & fedata$network.0.k <= 5, ]

fedata_net10 <- fedata[fedata$num.networks > 2 & fedata$network.0.k > 5, ]



# create a table with avg and sd
cast_fedata_table <- cast(data = fedata, formula = network.0.k ~ num.networks, 
    c(mean, sd))

fedata_table_full <- tabular(cast_fedata_table)

```


Create the tables

```r
# to print the table created with tabular

html(fedata_table_full)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">num.networks</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">1</th>
  <th colspan="2">2</th>
  <th colspan="2">3</th>
  <th colspan="2">4</th>
  <th colspan="2">5</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
</tr>
 <tr class="center">
  <th>network.0.k</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td>200000</td>
  <td>    0.0</td>
  <td>185872</td>
  <td>48393.0</td>
  <td>94754</td>
  <td>87017.3</td>
  <td>46362</td>
  <td>74283.4</td>
  <td>16010</td>
  <td>39960.1</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>200000</td>
  <td>    0.0</td>
  <td> 86945</td>
  <td>89375.0</td>
  <td>28802</td>
  <td>59958.0</td>
  <td> 4960</td>
  <td> 6859.0</td>
  <td> 6573</td>
  <td>21214.9</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>198631</td>
  <td>13690.0</td>
  <td> 58780</td>
  <td>81616.8</td>
  <td> 8648</td>
  <td>28085.7</td>
  <td> 3936</td>
  <td> 9068.2</td>
  <td> 3860</td>
  <td>10035.1</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td>200000</td>
  <td>    0.0</td>
  <td> 28262</td>
  <td>57696.1</td>
  <td> 4574</td>
  <td> 7209.6</td>
  <td> 2980</td>
  <td> 3574.8</td>
  <td> 2612</td>
  <td> 2726.5</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>196154</td>
  <td>27061.5</td>
  <td> 17577</td>
  <td>44695.4</td>
  <td> 4056</td>
  <td> 6689.6</td>
  <td> 2490</td>
  <td> 1429.9</td>
  <td> 2126</td>
  <td> 1237.3</td>
</tr>
 <tr class="center">
  <th class="left">10</th>
  <td>164460</td>
  <td>76246.4</td>
  <td>  7392</td>
  <td>27984.9</td>
  <td> 2632</td>
  <td> 4073.6</td>
  <td> 2088</td>
  <td> 1910.5</td>
  <td> 1962</td>
  <td> 1154.9</td>
</tr>
 <tr class="center">
  <th class="left">20</th>
  <td> 73368</td>
  <td>95460.5</td>
  <td>  2680</td>
  <td> 6511.7</td>
  <td> 1802</td>
  <td>  877.8</td>
  <td> 1868</td>
  <td>  860.2</td>
  <td> 1984</td>
  <td> 1096.2</td>
</tr>
 <tr class="center">
  <th class="left">30</th>
  <td>  1936</td>
  <td> 1090.0</td>
  <td>  1942</td>
  <td> 1228.1</td>
  <td> 2110</td>
  <td> 1471.4</td>
  <td> 1770</td>
  <td>  913.8</td>
  <td> 1878</td>
  <td>  910.1</td>
</tr>
 <tr class="center">
  <th class="left">40</th>
  <td>  1710</td>
  <td>  706.3</td>
  <td>  1866</td>
  <td> 1037.5</td>
  <td> 1746</td>
  <td>  837.9</td>
  <td> 1794</td>
  <td>  913.8</td>
  <td> 1838</td>
  <td>  808.9</td>
</tr>
 <tr class="center">
  <th class="left">50</th>
  <td>  1688</td>
  <td>  715.1</td>
  <td>  1906</td>
  <td>  974.2</td>
  <td> 1894</td>
  <td>  868.0</td>
  <td> 1808</td>
  <td> 1045.8</td>
  <td> 1714</td>
  <td> 1058.4</td>
</tr>
</tbody>
</table>

```r


# print this to a file to use in the paper

Hmisc::latex(fedata_table_full, file = "tex/regular_encounters_full.tex", booktabs = T)
```


Now to observe the distribution of the number of encounters, necessary to achieve consensus, we look at the box plots for **k = {1,2,3,4,5}** and **k = {10,20,30,40,50}** respectively. We look at **configurations with a number of networks > 3** since less networks require more connectivity to allow consensus to be reached 100% of the time.


```r
plot <- plot.exp.box(data = fedata_net1, x_factor = as.factor(fedata_net1$num.networks), 
    data_y = fedata_net1$value, fill_factor = as.factor(fedata_net1$network.0.k), 
    fill_label = "K", x_label = "Number of Networks", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-9](figure/unnamed-chunk-91.png) 

```r

plot <- plot.exp.box(data = fedata_net10, x_factor = as.factor(fedata_net10$num.networks), 
    data_y = fedata_net10$value, fill_factor = as.factor(fedata_net10$network.0.k), 
    fill_label = "K", x_label = "Number of Networks", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-9](figure/unnamed-chunk-92.png) 


To try to answer the question "why do some outliers show up in the data" (simulation runs that took more time than the typical run), I look at the outlier from the configuration **(networks=3, k = 10)**. What I'm trying to find is weather the network structure is the same from the other runs. 



```r
source("../R/read_network.R")

network_data <- fread("../data/regular_networks/networks.csv")
```

```
## Read 61.4% of 24675000 rowsRead 24675000 rows and 7 (of 7) columns from 0.405 GB file in 00:00:03
```

```r

# get outlier
outlier <- fedata_net10[fedata_net10$value > 30000 & fedata_net10$network.0.k == 
    10, ]
normal <- fedata_net10[fedata_net10$value < 3000 & fedata_net10$network.0.k == 
    10, ]




# get outlier network
network_outlier_data <- network_data[network_data$cfg.id == outlier$cfg.id & 
    network_data$run == outlier$run, ]
outlier_net <- read.composite.network(network_data = network_outlier_data)


fdata <- fedata_net10[fedata_net10$network.0.k == 10 & fedata_net10$num.networks == 
    3 & fedata_net10$value < 5000, ]  #filter the data
plot <- plot.exp.box(data = fdata, x_factor = as.factor(fdata$num.networks), 
    data_y = fdata$value, fill_factor = as.factor(fdata$network.0.k), fill_label = "K", 
    x_label = "Number of Networks", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-10](figure/unnamed-chunk-10.png) 

```r

normal <- normal[2, ]  #choose one possible configuration (not an outlier)
normal
```

```
##      cfg.id run num.networks network.0.k         variable value
## 2502     26   2            3          10 total-encounters  2100
```

```r


network_normal_data <- network_data[network_data$cfg.id == normal$cfg.id & network_data$run == 
    normal$run, ]
normal_net <- read.composite.network(network_data = network_normal_data)

# outlier network properties
outlier_net_props <- read.composite.properties(outlier_net)
normal_net_props <- read.composite.properties(normal_net)
```



```r
outlier_net_props
```

```
##   nodes edges    cc   apl
## 1   100  2455 0.545 1.504
```

```r
normal_net_props
```

```
##   nodes edges     cc   apl
## 1   100  2448 0.5461 1.505
```

There is no significant differences between the network from the outlier simulation run and one case from a normal run. 
This suggests that this can be a property of the game itself (see plots bellow) and some "event" leads the convergence to be slower than those of the rest of the runs. My hypothesis is that the agents reach a state from which converging towards consensus is significantly harder. This needs further analysis. One idea is to look at difference between the observations (agent memory) for both opinions throughout the simulation. 

Another idea is to look at the sate of the agents and their location in the underlying networks. If networks contain some sort of self-reinforcing structures, this can cause the convergence to be slowed. Daniel Villatoro found these structures in models such as scale-free networks (see [http://dl.acm.org/citation.cfm?id=2451250](here)). Self-reinforcing structures are subgraphs that converge to consensus, and due to its structure (and the nature of the consensus game), lead the agents in that subgroup to reinforce one another. Breaking these consensus groups can be particularly difficult even if the whole society has converged to a different opinion value. 


```r
opinion_data <- read.opinion.progress("../data/regular_networks/opinion_progress.csv")
# filter opinion to outlier run and normal run
outlier_run <- opinion_data[opinion_data$cfg.id == outlier$cfg.id & opinion_data$run == 
    outlier$run, ]
normal_run <- opinion_data[opinion_data$cfg.id == normal$cfg.id & opinion_data$run == 
    normal$run, ]
```



```r
plot_run_outlier <- plot_opinion(opinion_data = outlier_run)
plot_run_normal <- plot_opinion(opinion_data = normal_run)


plot_run_normal + labs(title = "Normal Run")
```

![plot of chunk unnamed-chunk-13](figure/unnamed-chunk-131.png) 

```r
plot_run_outlier + labs(title = "Outlier Run")
```

![plot of chunk unnamed-chunk-13](figure/unnamed-chunk-132.png) 



# Convergence for Scale-Free Networks #
We now perform the same analysis for an homogenous scale-free configuration (scale-free networks in all the layers). 
To create the scale-free networks, we used the Barabasi-Albert model in which the networks are expanded by preferential 
attachment. The networks have an additional parameter d which dictates how many connections are added each time a new node 
is added to the network. We varied this parameter and considered the values ** d = {1,2,3,4,5} **.

We first look at the number of convergences to total consensus in 100 simulation runs. 

```r
# Read the Parameters for this experiment
params <- read.exp.parameters(param_file_name = "../data/scale-free_networks/param-space_2014-05-30_18:38:14experiment:1_.csv")

# read the adata related to consensus was achieved before
require(data.table)
convergence_data <- fread("../data/scale-free_networks/consensus_achieved.csv")
convergence_data <- as.data.frame(convergence_data)[, -ncol(convergence_data)]
convergence_data <- merge(convergence_data, params, by = "cfg.id")
```



We can now create a table to display the percentage of convergences to total 
consensus **for each value of d and number of networks**.


```r
require(reshape)
require(tables)

# filter some things out
fcdata <- melt.data.frame(convergence_data, id.vars = c("cfg.id", "run", "num.networks", 
    "network.0.d"), measure.vars = c("consensus-achieved"))

# I can also cast to obtain multiple values like summary this will be useful
# later for the table with the number of encounters convergence_table <-
# cast(fcdata, num.networks~network.0.k~value, sum)

# convergence_table

fcdata_table <- aggregate(data = fcdata, fcdata$value ~ num.networks + fcdata$network.0.d, 
    FUN = sum)
colnames(fcdata_table) <- c("num.networks", "d", "value")

# create a pretty table for latex
latex_table <- tabular(cast(fcdata_table, num.networks ~ d, value = "value"))
```



```r
html(latex_table)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="5">d</th>
</tr>
 <tr class="center">
  <th>num.networks</th>
  <th>1</th>
  <th>2</th>
  <th>3</th>
  <th>4</th>
  <th>5</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td> 0</td>
  <td> 30</td>
  <td> 88</td>
  <td> 99</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>35</td>
  <td> 98</td>
  <td> 97</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>76</td>
  <td> 99</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td>96</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>97</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
</tbody>
</table>

```r

# I can also save this table to a file for later reference
latex(latex_table, file = "tex/scale-free_convergence.tex", booktabs = T, )
```


# Number of Encounters for Scale-Free Networks #
Now we analise the number of encouters necessary to achieve consensus. Or the total number of encounters that 
were performed if consensus was not achieved. The data for the encounters contains the following variables.

```r
encounter_data <- fread("../data/scale-free_networks/num_encounters.csv")
encounter_data <- as.data.frame(encounter_data)[, -ncol(encounter_data)]
head(encounter_data)
```

```
##   step run cfg.id total-encounters
## 1 2000   3      1           200000
## 2 2000   7      1           200000
## 3 2000   8      1           200000
## 4 2000   1      1           200000
## 5 2000   5      1           200000
## 6 2000   2      1           200000
```

To get the information for how many networks were in the simulation and what was the **d** value, we 
can merge the data like we have done previously. 

```r
encounter_data <- merge(encounter_data, params, by = "cfg.id")
```


We now filter some of the variables out.

```r
# filter some things out
fedata <- melt.data.frame(encounter_data, id.vars = c("cfg.id", "run", "num.networks", 
    "network.0.d"), measure.vars = c("total-encounters"))
head(fedata)
```

```
##   cfg.id run num.networks network.0.d         variable  value
## 1      1   3            1           1 total-encounters 200000
## 2      1   7            1           1 total-encounters 200000
## 3      1   8            1           1 total-encounters 200000
## 4      1   1            1           1 total-encounters 200000
## 5      1   5            1           1 total-encounters 200000
## 6      1   2            1           1 total-encounters 200000
```

```r



# create a table with avg and sd
cast_fedata_table <- cast(data = fedata, formula = network.0.d ~ num.networks, 
    c(mean, sd))

fedata_table_full <- tabular(cast_fedata_table)

```


Create the tables

```r
# to print the table created with tabular

html(fedata_table_full)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">num.networks</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">1</th>
  <th colspan="2">2</th>
  <th colspan="2">3</th>
  <th colspan="2">4</th>
  <th colspan="2">5</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
</tr>
 <tr class="center">
  <th>network.0.d</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td>200000</td>
  <td>    0</td>
  <td>141085</td>
  <td>83720</td>
  <td>66020</td>
  <td>82601</td>
  <td>17712</td>
  <td>42444</td>
  <td>14917</td>
  <td>38343.6</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>150632</td>
  <td>78710</td>
  <td> 21654</td>
  <td>41341</td>
  <td> 7555</td>
  <td>21407</td>
  <td> 5890</td>
  <td>10889</td>
  <td> 3638</td>
  <td> 5127.0</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td> 37824</td>
  <td>64073</td>
  <td> 12309</td>
  <td>36441</td>
  <td> 5299</td>
  <td>20035</td>
  <td> 2804</td>
  <td> 3791</td>
  <td> 2618</td>
  <td> 2445.4</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td> 13751</td>
  <td>33295</td>
  <td>  4846</td>
  <td> 7921</td>
  <td> 2852</td>
  <td> 2766</td>
  <td> 2370</td>
  <td> 1441</td>
  <td> 2200</td>
  <td> 1433.4</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>  8802</td>
  <td>18754</td>
  <td>  2536</td>
  <td> 1880</td>
  <td> 3204</td>
  <td>11008</td>
  <td> 2166</td>
  <td> 1269</td>
  <td> 1958</td>
  <td>  971.6</td>
</tr>
</tbody>
</table>

```r


# print this to a file to use in the paper

Hmisc::latex(fedata_table_full, file = "tex/scale-free_encounters_full.tex", 
    booktabs = T)
```


Now to observe the distribution of the number of encounters, necessary to achieve consensus, we look at the box plots for **d = {1,2,3,4,5}**. We look at **configurations with a number of networks > 3** since less networks require more connectivity to allow consensus to be reached 100% of the time.


```r
plot <- plot.exp.box(data = fedata, x_factor = as.factor(fedata$num.networks), 
    data_y = fedata$value, fill_factor = as.factor(fedata$network.0.d), fill_label = "d", 
    x_label = "Number of Networks", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-21](figure/unnamed-chunk-21.png) 


Focusing on the runs where the **number of encounters was < 2000** (some outliers are not present, see previous plots for that)


```r
fedata <- fedata[fedata$num.networks >= 3 & fedata$network.0.d > 1 & fedata$value < 
    10000, ]
plot <- plot.exp.box(data = fedata, x_factor = as.factor(fedata$num.networks), 
    data_y = fedata$value, fill_factor = as.factor(fedata$network.0.d), fill_label = "d", 
    x_label = "Number of Networks", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-22](figure/unnamed-chunk-22.png) 


# Convergence for Heterogeneous Configuration (K-Regular Network + Scale-free Network) #
Now we analyse what happens when we use an heterogenous configuration, this is, each layer in the model uses different 
network models. In a first experiment, we use a K-Regular network for one layer and a Scale-free network for the other. 

```r
# Read the Parameters for this experiment
params <- read.exp.parameters(param_file_name = "../data/scale-free_regular/param-space_2014-05-30_18:40:41experiment:2_.csv")

# read the adata related to consensus was achieved before
require(data.table)
convergence_data <- fread("../data/scale-free_regular/consensus_achieved.csv")
convergence_data <- as.data.frame(convergence_data)[, -ncol(convergence_data)]
convergence_data <- merge(convergence_data, params, by = "cfg.id")
```


We can now create a table to display the percentage of convergences to total 
consensus **for each value of k and d**. The **number of networks** in this experiment is allways **2**.


```r
require(reshape)
require(tables)

# filter some things out
fcdata <- melt.data.frame(convergence_data, id.vars = c("cfg.id", "run", "network.0.k", 
    "network.1.d"), measure.vars = c("consensus-achieved"))

# convergence_table

fcdata_table <- aggregate(data = fcdata, fcdata$value ~ network.1.d + fcdata$network.0.k, 
    FUN = sum)
colnames(fcdata_table) <- c("d", "k", "value")

# create a pretty table for latex
latex_table <- tabular(cast(fcdata_table, d ~ k, value = "value"))
```



```r
html(latex_table)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">k</th>
</tr>
 <tr class="center">
  <th>d</th>
  <th>1</th>
  <th>2</th>
  <th>3</th>
  <th>4</th>
  <th>5</th>
  <th>10</th>
  <th>20</th>
  <th>30</th>
  <th>40</th>
  <th>50</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td>18</td>
  <td>47</td>
  <td>55</td>
  <td>67</td>
  <td>61</td>
  <td>76</td>
  <td> 77</td>
  <td> 81</td>
  <td> 75</td>
  <td> 82</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>63</td>
  <td>72</td>
  <td>88</td>
  <td>89</td>
  <td>90</td>
  <td>97</td>
  <td>100</td>
  <td>100</td>
  <td> 99</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>77</td>
  <td>86</td>
  <td>87</td>
  <td>97</td>
  <td>98</td>
  <td>99</td>
  <td> 98</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td>73</td>
  <td>92</td>
  <td>92</td>
  <td>97</td>
  <td>96</td>
  <td>96</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>87</td>
  <td>85</td>
  <td>94</td>
  <td>94</td>
  <td>98</td>
  <td>99</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
</tbody>
</table>

```r

# I can also save this table to a file for later reference
latex(latex_table, file = "tex/regular_scale-free_convergence.tex", booktabs = T, 
    )
```


This table shows the percentage of simulation runs that converged to total consensus over 100 
independent runs. 

# Number of Encounters for Heterogeneous Configuration (K-Regular Network + Scale-free Network) #
In this section, we analise the number of encouters necessary to achieve consensus with this heterogenous setup.
The data for the encounters contains the following variables.

```r
encounter_data <- fread("../data/scale-free_regular/num_encounters.csv")
encounter_data <- as.data.frame(encounter_data)[, -ncol(encounter_data)]
head(encounter_data)
```

```
##   step run cfg.id total-encounters
## 1 2000   4      1           200000
## 2 2000   1      1           200000
## 3 2000   2      1           200000
## 4 2000   6      1           200000
## 5 2000   5      1           200000
## 6 2000   3      1           200000
```

To get the information for the d and k values we can merge the data with the parameter space

```r
encounter_data <- merge(encounter_data, params, by = "cfg.id")
```


We now filter some of the variables out.

```r
# filter some things out
fedata <- melt.data.frame(encounter_data, id.vars = c("cfg.id", "run", "network.0.k", 
    "network.1.d"), measure.vars = c("total-encounters"))
head(fedata)
```

```
##   cfg.id run network.0.k network.1.d         variable  value
## 1      1   4           1           1 total-encounters 200000
## 2      1   1           1           1 total-encounters 200000
## 3      1   2           1           1 total-encounters 200000
## 4      1   6           1           1 total-encounters 200000
## 5      1   5           1           1 total-encounters 200000
## 6      1   3           1           1 total-encounters 200000
```

```r

# filter encounter data include only num networks > 3
fedata_net1 <- fedata[fedata$network.0.k <= 5, ]

fedata_net10 <- fedata[fedata$network.0.k > 5, ]



# create a table with avg and sd
cast_fedata_table <- cast(data = fedata, formula = network.0.k ~ network.1.d, 
    c(mean, sd))

fedata_table_full <- tabular(cast_fedata_table)

```


Create the tables

```r
# to print the table created with tabular

html(fedata_table_full)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">network.1.d</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">1</th>
  <th colspan="2">2</th>
  <th colspan="2">3</th>
  <th colspan="2">4</th>
  <th colspan="2">5</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
</tr>
 <tr class="center">
  <th>network.0.k</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td>173312</td>
  <td>61519</td>
  <td>100175</td>
  <td>88406</td>
  <td>63191</td>
  <td>81071</td>
  <td>73715</td>
  <td>84549</td>
  <td>51313</td>
  <td>67704</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>118591</td>
  <td>90107</td>
  <td> 72054</td>
  <td>86077</td>
  <td>43308</td>
  <td>70318</td>
  <td>31756</td>
  <td>58760</td>
  <td>43281</td>
  <td>72182</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>109155</td>
  <td>88722</td>
  <td> 38270</td>
  <td>66714</td>
  <td>34899</td>
  <td>65533</td>
  <td>26412</td>
  <td>55589</td>
  <td>23436</td>
  <td>49978</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td> 80035</td>
  <td>88719</td>
  <td> 33339</td>
  <td>64075</td>
  <td>21289</td>
  <td>45725</td>
  <td>15575</td>
  <td>39516</td>
  <td>24034</td>
  <td>52407</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td> 89179</td>
  <td>91823</td>
  <td> 31044</td>
  <td>62485</td>
  <td>13908</td>
  <td>36791</td>
  <td>14112</td>
  <td>39490</td>
  <td> 9252</td>
  <td>28404</td>
</tr>
 <tr class="center">
  <th class="left">10</th>
  <td> 62416</td>
  <td>81036</td>
  <td> 11017</td>
  <td>35071</td>
  <td> 9095</td>
  <td>27266</td>
  <td>12182</td>
  <td>39798</td>
  <td> 5559</td>
  <td>20448</td>
</tr>
 <tr class="center">
  <th class="left">20</th>
  <td> 61371</td>
  <td>81409</td>
  <td>  6680</td>
  <td>17900</td>
  <td> 6944</td>
  <td>27826</td>
  <td> 4721</td>
  <td>19832</td>
  <td> 2390</td>
  <td> 2313</td>
</tr>
 <tr class="center">
  <th class="left">30</th>
  <td> 51559</td>
  <td>77468</td>
  <td>  4980</td>
  <td>12740</td>
  <td> 5095</td>
  <td>20028</td>
  <td> 2268</td>
  <td> 1355</td>
  <td> 2046</td>
  <td> 1225</td>
</tr>
 <tr class="center">
  <th class="left">40</th>
  <td> 58625</td>
  <td>83049</td>
  <td>  5483</td>
  <td>20169</td>
  <td> 2726</td>
  <td> 3735</td>
  <td> 2346</td>
  <td> 1503</td>
  <td> 2412</td>
  <td> 1874</td>
</tr>
 <tr class="center">
  <th class="left">50</th>
  <td> 48702</td>
  <td>74718</td>
  <td>  6568</td>
  <td>22611</td>
  <td> 2566</td>
  <td> 1716</td>
  <td> 2362</td>
  <td> 1619</td>
  <td> 1980</td>
  <td> 1081</td>
</tr>
</tbody>
</table>

```r


# print this to a file to use in the paper

Hmisc::latex(fedata_table_full, file = "tex/regular_scale-free_encounters_full.tex", 
    booktabs = T)
```


Now to observe the distribution of the number of encounters, necessary to achieve consensus, we look at the box plots for **k = {1,2,3,4,5}** and **k = {10,20,30,40,50}** respectively.


```r
plot <- plot.exp.box(data = fedata_net1, x_factor = as.factor(fedata_net1$network.1.d), 
    data_y = fedata_net1$value, fill_factor = as.factor(fedata_net1$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-30](figure/unnamed-chunk-301.png) 

```r

plot <- plot.exp.box(data = fedata_net10, x_factor = as.factor(fedata_net10$network.1.d), 
    data_y = fedata_net10$value, fill_factor = as.factor(fedata_net10$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-30](figure/unnamed-chunk-302.png) 


Focusing now on the best performing configurations and on the runs that produced a convergence in less than 50000 encounters, the distribution of the number of encounters is as follows. 


```r
fedata_net10 <- fedata_net10[fedata_net10$network.1.d > 1 & fedata_net10$value <= 
    10000, ]

plot <- plot.exp.box(data = fedata_net10, x_factor = as.factor(fedata_net10$network.1.d), 
    data_y = fedata_net10$value, fill_factor = as.factor(fedata_net10$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-31](figure/unnamed-chunk-31.png) 


# Heterogeneous Network Properties #
In this section we analyse the properties of this heterogenous setup. This is, what happens when you mix 
k-regular networks with a scale-free network. 


```r
source("../R/read_network.R")
network_data <- fread("../data/scale-free_regular/networks.csv")
# filter the data, we just need the data from one simulation run
network_data <- network_data[network_data$cfg.id == fedata_net10[1, ]$cfg.id & 
    network_data$run == fedata_net10[1, ]$run, ]

k_regular_network <- read.single.network(data = network_data, layer = 0)
scale_free_network <- read.single.network(data = network_data, layer = 1)
combined_network <- k_regular_network + scale_free_network
```


We combine a 10-Regular and a Scale-free network from the previous experiment (D = 2) by merging the overllaping edges. 

```r
network1 <- k_regular_network
network2 <- scale_free_network




color1 <- "#7D9C9F"
color2 <- "#B1B1B1"
color_over <- "#FF003F"

E(network1)$color <- color1
E(network2)$color <- color2

el1 <- apply(get.edgelist(network1), 1, paste, collapse = "-")
el2 <- apply(get.edgelist(network2), 1, paste, collapse = "-")
elc <- apply(get.edgelist(combined_network), 1, paste, collapse = "-")

E(combined_network)$color <- ifelse((elc %in% el1) & (elc %in% el2), color_over, 
    ifelse((elc %in% el1), color1, color2))


par(mfrow = c(1, 3))
plot(network1, vertex.size = 2, vertex.label = NA, layout = layout.kamada.kawai, 
    main = "10-Regular Network")
plot(network2, vertex.size = 2, vertex.label = NA, layout = layout.kamada.kawai, 
    main = "Scale-Free with D = 2")
plot(combined_network, vertex.size = 2, vertex.label = NA, layout = layout.kamada.kawai, 
    main = "Combined Networks")
```

![plot of chunk unnamed-chunk-33](figure/unnamed-chunk-33.png) 


We now plot the degree distribution using a log scale. We do this for the **10-Regular** Network, the **Scale-Free Network with d = 2**, and the combined network.


```r
par(mfrow = c(1, 3))
plot.degree.distribution(network = k_regular_network, "10-Regular Network")
```

```
## $breaks
## [1] 2 4
## 
## $counts
## [1] 100
## 
## $density
## [1] 0.5
## 
## $mids
## [1] 3
## 
## $xname
## [1] "log(distribution + 1)"
## 
## $equidist
## [1] TRUE
## 
## attr(,"class")
## [1] "histogram"
```

```r
plot.degree.distribution(network = scale_free_network, "Scale-Free Network with D = 2")
```

```
## $breaks
## [1] 1.0 1.5 2.0 2.5 3.0 3.5 4.0
## 
## $counts
## [1] 65 25  6  3  0  1
## 
## $density
## [1] 1.30 0.50 0.12 0.06 0.00 0.02
## 
## $mids
## [1] 1.25 1.75 2.25 2.75 3.25 3.75
## 
## $xname
## [1] "log(distribution + 1)"
## 
## $equidist
## [1] TRUE
## 
## attr(,"class")
## [1] "histogram"
```

```r
plot.degree.distribution(network = combined_network, "Combined network")
```

![plot of chunk unnamed-chunk-34](figure/unnamed-chunk-34.png) 

```
## $breaks
##  [1] 3.0 3.1 3.2 3.3 3.4 3.5 3.6 3.7 3.8 3.9
## 
## $counts
## [1] 21 57 15  2  3  0  1  0  1
## 
## $density
## [1] 2.1 5.7 1.5 0.2 0.3 0.0 0.1 0.0 0.1
## 
## $mids
## [1] 3.05 3.15 3.25 3.35 3.45 3.55 3.65 3.75 3.85
## 
## $xname
## [1] "log(distribution + 1)"
## 
## $equidist
## [1] TRUE
## 
## attr(,"class")
## [1] "histogram"
```




# Regular / Scale-Free / Scale-Free Configuration #
We look at a final heterogeneous configuration. In this experiment we used 1 K-Regular network and 2 Scale-Free Networks 
with varying k and d parameters. To analyse the convergence and number of encounters to achieve consensus, we consider 
homogenous parameter configurations for scale-free networks (the same value of d for both networks).

## CONVERGENCE FOR REG/SF/SF ##


```r
# Read the Parameters for this experiment
params <- read.exp.parameters(param_file_name = "../data/scale-free_scale-free_regular/param-space_2014-05-30_18:43:13experiment:2_.csv")

# read the adata related to consensus was achieved before
require(data.table)
convergence_data <- fread("../data/scale-free_scale-free_regular/consensus_achieved.csv")
convergence_data <- as.data.frame(convergence_data)[, -ncol(convergence_data)]
convergence_data <- merge(convergence_data, params, by = "cfg.id")
```


We can now create a table to display the percentage of convergences to total 
consensus **for each value of k and d**. The **number of networks** in this experiment is allways **2**.


```r
require(reshape)
require(tables)

# filter some things out
fcdata <- melt.data.frame(convergence_data, id.vars = c("cfg.id", "run", "network.0.k", 
    "network.1.d", "network.2.d"), measure.vars = c("consensus-achieved"))

# filter the data and get the data for homogenous d configurations
# (network.1.d == network.2.d)
fcdata <- fcdata[fcdata$network.1.d == fcdata$network.2.d, ]

# convergence_table

fcdata_table <- aggregate(data = fcdata, fcdata$value ~ network.1.d + fcdata$network.0.k, 
    FUN = sum)
colnames(fcdata_table) <- c("d", "k", "value")

# create a pretty table for latex
latex_table <- tabular(cast(fcdata_table, d ~ k, value = "value"))
```



```r
html(latex_table)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">k</th>
</tr>
 <tr class="center">
  <th>d</th>
  <th>1</th>
  <th>2</th>
  <th>3</th>
  <th>4</th>
  <th>5</th>
  <th>10</th>
  <th>20</th>
  <th>30</th>
  <th>40</th>
  <th>50</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td> 74</td>
  <td> 85</td>
  <td> 85</td>
  <td> 92</td>
  <td> 93</td>
  <td> 94</td>
  <td> 94</td>
  <td> 91</td>
  <td> 91</td>
  <td> 96</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td> 94</td>
  <td> 97</td>
  <td> 99</td>
  <td>100</td>
  <td> 99</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
  <td> 99</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td> 97</td>
  <td> 99</td>
  <td> 99</td>
  <td>100</td>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td> 99</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>100</td>
  <td>100</td>
  <td> 98</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
  <td>100</td>
</tr>
</tbody>
</table>

```r

# I can also save this table to a file for later reference
latex(latex_table, file = "tex/regular_scale-free_scale-free_convergence.tex", 
    booktabs = T, )
```


This table shows the percentage of simulation runs that converged to total consensus over 100 
independent runs. 

# Number of Encounters for REG/SF/SF #
In this section, we analise the number of encouters necessary to achieve consensus with this heterogenous setup.
The data for the encounters contains the following variables.

```r
encounter_data <- fread("../data/scale-free_scale-free_regular/num_encounters.csv")
encounter_data <- as.data.frame(encounter_data)[, -ncol(encounter_data)]
head(encounter_data)
```

```
##   step run cfg.id total-encounters
## 1   39   4      1             3900
## 2   71   8      1             7100
## 3   91   2      1             9100
## 4  155   6      1            15500
## 5   67   9      1             6700
## 6  131  10      1            13100
```

To get the information for the d and k values we can merge the data with the parameter space

```r
encounter_data <- merge(encounter_data, params, by = "cfg.id")
```


We now filter some of the variables out.

```r
# filter some things out
fedata <- melt.data.frame(encounter_data, id.vars = c("cfg.id", "run", "network.0.k", 
    "network.1.d", "network.2.d"), measure.vars = c("total-encounters"))
head(fedata)
```

```
##   cfg.id run network.0.k network.1.d network.2.d         variable value
## 1      1   4           1           1           1 total-encounters  3900
## 2      1   8           1           1           1 total-encounters  7100
## 3      1   2           1           1           1 total-encounters  9100
## 4      1   6           1           1           1 total-encounters 15500
## 5      1   9           1           1           1 total-encounters  6700
## 6      1  10           1           1           1 total-encounters 13100
```

```r

# filter the data and get the data for homogenous d configurations
# (network.1.d == network.2.d)
fedata <- fedata[fedata$network.1.d == fedata$network.2.d, ]

# filter encounter data include only num networks > 3
fedata_net1 <- fedata[fedata$network.0.k <= 5, ]

fedata_net10 <- fedata[fedata$network.0.k > 5, ]



# create a table with avg and sd
cast_fedata_table <- cast(data = fedata, formula = network.0.k ~ network.1.d, 
    c(mean, sd))

fedata_table_full <- tabular(cast_fedata_table)

```


Create the tables

```r
# to print the table created with tabular

html(fedata_table_full)
```

<table frame="hsides" rules="groups">
<thead>
<tr class="center">
  <th>&nbsp;</th>
  <th colspan="10">network.1.d</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">1</th>
  <th colspan="2">2</th>
  <th colspan="2">3</th>
  <th colspan="2">4</th>
  <th colspan="2">5</th>
</tr>
 <tr class="center">
  <th>&nbsp;</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
  <th colspan="2">result_variable</th>
</tr>
 <tr class="center">
  <th>network.0.k</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
  <th>mean</th>
  <th>sd</th>
</tr>
</thead>
<tbody>
<tr class="center">
  <th class="left">1</th>
  <td>74046</td>
  <td>83329</td>
  <td>22728</td>
  <td>49046</td>
  <td>13533</td>
  <td>37543</td>
  <td>8019</td>
  <td>21971</td>
  <td>8236</td>
  <td>22440</td>
</tr>
 <tr class="center">
  <th class="left">2</th>
  <td>40581</td>
  <td>69103</td>
  <td>17555</td>
  <td>41600</td>
  <td> 8733</td>
  <td>23959</td>
  <td>4794</td>
  <td> 8275</td>
  <td>4436</td>
  <td> 8629</td>
</tr>
 <tr class="center">
  <th class="left">3</th>
  <td>44017</td>
  <td>71382</td>
  <td> 8623</td>
  <td>23087</td>
  <td> 5875</td>
  <td>20313</td>
  <td>4652</td>
  <td>15028</td>
  <td>6954</td>
  <td>27907</td>
</tr>
 <tr class="center">
  <th class="left">4</th>
  <td>30690</td>
  <td>57132</td>
  <td> 5222</td>
  <td>10111</td>
  <td> 4376</td>
  <td> 8190</td>
  <td>3496</td>
  <td> 4182</td>
  <td>4226</td>
  <td>11201</td>
</tr>
 <tr class="center">
  <th class="left">5</th>
  <td>23171</td>
  <td>50539</td>
  <td> 7609</td>
  <td>22881</td>
  <td> 5103</td>
  <td>19961</td>
  <td>3552</td>
  <td> 4217</td>
  <td>3190</td>
  <td> 5772</td>
</tr>
 <tr class="center">
  <th class="left">10</th>
  <td>24208</td>
  <td>50403</td>
  <td> 6701</td>
  <td>21395</td>
  <td> 2770</td>
  <td> 2092</td>
  <td>2816</td>
  <td> 2926</td>
  <td>2254</td>
  <td> 1489</td>
</tr>
 <tr class="center">
  <th class="left">20</th>
  <td>22522</td>
  <td>48657</td>
  <td> 4996</td>
  <td> 9163</td>
  <td> 2880</td>
  <td> 2508</td>
  <td>2420</td>
  <td> 2016</td>
  <td>2278</td>
  <td> 2011</td>
</tr>
 <tr class="center">
  <th class="left">30</th>
  <td>26393</td>
  <td>58501</td>
  <td> 3328</td>
  <td> 6265</td>
  <td> 2356</td>
  <td> 1798</td>
  <td>2204</td>
  <td> 1367</td>
  <td>2114</td>
  <td> 1241</td>
</tr>
 <tr class="center">
  <th class="left">40</th>
  <td>27021</td>
  <td>56626</td>
  <td> 5277</td>
  <td>19989</td>
  <td> 2348</td>
  <td> 1476</td>
  <td>2262</td>
  <td> 1317</td>
  <td>2160</td>
  <td> 1108</td>
</tr>
 <tr class="center">
  <th class="left">50</th>
  <td>18120</td>
  <td>41733</td>
  <td> 3484</td>
  <td> 3988</td>
  <td> 3566</td>
  <td> 5620</td>
  <td>2172</td>
  <td> 1636</td>
  <td>2162</td>
  <td> 1387</td>
</tr>
</tbody>
</table>

```r


# print this to a file to use in the paper

Hmisc::latex(fedata_table_full, file = "tex/regular_scale-free_scale_free_encounters_full.tex", 
    booktabs = T)
```


Now to observe the distribution of the number of encounters, necessary to achieve consensus, we look at the box plots for **k = {1,2,3,4,5}** and **k = {10,20,30,40,50}** respectively.


```r
plot <- plot.exp.box(data = fedata_net1, x_factor = as.factor(fedata_net1$network.1.d), 
    data_y = fedata_net1$value, fill_factor = as.factor(fedata_net1$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-42](figure/unnamed-chunk-421.png) 

```r

plot <- plot.exp.box(data = fedata_net10, x_factor = as.factor(fedata_net10$network.1.d), 
    data_y = fedata_net10$value, fill_factor = as.factor(fedata_net10$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-42](figure/unnamed-chunk-422.png) 


Focusing now on the best performing configurations and on the runs that produced a convergence in less than 50000 encounters, the distribution of the number of encounters is as follows. 


```r
fedata_net10 <- fedata_net10[fedata_net10$network.1.d > 1 & fedata_net10$value <= 
    10000, ]

plot <- plot.exp.box(data = fedata_net10, x_factor = as.factor(fedata_net10$network.1.d), 
    data_y = fedata_net10$value, fill_factor = as.factor(fedata_net10$network.0.k), 
    fill_label = "K", x_label = "D", y_label = "Number of Encounters")

plot
```

![plot of chunk unnamed-chunk-43](figure/unnamed-chunk-43.png) 





